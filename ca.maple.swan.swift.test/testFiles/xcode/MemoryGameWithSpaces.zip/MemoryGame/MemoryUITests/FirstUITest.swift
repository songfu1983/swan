//
//  FirstUITest.swift
//  MemoryUITests
//
//  Created by Abdul Ali Bangash on 2020-01-02.
//  Copyright © 2020 Matias Villaverde. All rights reserved.
//

import XCTest

class FirstUITest: XCTestCase {

    override func setUp() {
        // Put setup code here. This method is called before the invocation of each test method in the class.

        // In UI tests it is usually best to stop immediately when a failure occurs.
        continueAfterFailure = false

        // UI tests must launch the application that they test. Doing this in setup will make sure it happens for each test method.
        XCUIApplication().launch()

        // In UI tests it’s important to set the initial state - such as interface orientation - required for your tests before they run. The setUp method is a good place to do this.
    }

    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

    func testExample() {
        
        let collectionViewsQuery = XCUIApplication().collectionViews
        let cardBackElement = collectionViewsQuery.children(matching: .cell).element(boundBy: 9).otherElements.containing(.image, identifier:"card_back").element
        cardBackElement.tap()
        
        let cardBackElement2 = collectionViewsQuery.children(matching: .cell).element(boundBy: 14).otherElements.containing(.image, identifier:"card_back").element
        cardBackElement2.tap()
        collectionViewsQuery.children(matching: .cell).element(boundBy: 18).otherElements.containing(.image, identifier:"card_back").element.tap()
        cardBackElement2.tap()
        collectionViewsQuery.children(matching: .cell).element(boundBy: 6).otherElements.containing(.image, identifier:"card_back").element.tap()
        
        let cardBackElement3 = collectionViewsQuery.children(matching: .cell).element(boundBy: 16).otherElements.containing(.image, identifier:"card_back").element
        cardBackElement3.tap()
        cardBackElement.tap()
        cardBackElement3.tap()
        cardBackElement2.tap()
        collectionViewsQuery.children(matching: .cell).element(boundBy: 13).otherElements.containing(.image, identifier:"card_back").element.tap()
                // Use recording to get started writing UI tests.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }

}
